package com.zhaopin.test.sdk2.controllers;

import com.cc.sdk2.jsdk.commons.result.ApiResult;
import com.cc.sdk2.jsdk.commons.result.ResultBuilder;
import com.cc.sdk2.rabbitmq.producer.RabbitMQProducer;
import com.cc.sdk2.redis.clients.RedisClient;
import com.cc.sdk2.springboot.web.configurations.mvc.version.ApiVersion;
import com.zhaopin.test.sdk2.dao.JobFairInfoDao;
import com.zhaopin.test.sdk2.dao.LiveRoomDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 10:46 2021/2/22
 */
@RestController
@RequestMapping(value = "test")
public class TestController {

    @Autowired
    private RedisClient redisClient;
    @Autowired
    private LiveRoomDao liveRoomDao;
    @Autowired
    private JobFairInfoDao jobFairInfoDao;

    @Autowired
    private RabbitMQProducer msgCenterProducer;

    @ApiVersion(vNo = 1.0F)
    @RequestMapping("{v}/testVersion")
    public ApiResult testApiVersion() {
        return ResultBuilder.success();
    }

    @RequestMapping(value = "{v}/testRedis")
    @ApiVersion(vNo = 1.0F)
    public ApiResult testRedis() {
        redisClient.set("test", "test123");
        return ResultBuilder.success(redisClient.get("test"));
    }


    @RequestMapping(value = "{v}/testLiveb")
    @ApiVersion(vNo = 1.0F)
    public ApiResult testDatabase() {
        return ResultBuilder.success(liveRoomDao.getByLiveRoomId(432L));
    }

    @RequestMapping(value = "{v}/testJobFair")
    @ApiVersion(vNo = 1.0F)
    public ApiResult testDatabase1() {
        return ResultBuilder.success(jobFairInfoDao.getById(72));
    }

    @RequestMapping(value = "{v}/testRabbitMQ")
    @ApiVersion(vNo = 1.0F)
    public ApiResult testRabbitMq() {
        try {
            msgCenterProducer.messageBuilder().body("{\"name\": \"test\"}".getBytes(StandardCharsets.UTF_8)).send();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResultBuilder.success();
    }


}
