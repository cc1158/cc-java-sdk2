package com.zhaopin.test.sdk2.config;

import com.cc.sdk2.springboot.web.configurations.mvc.BaseWebMvcConfig;
import org.springframework.context.annotation.Configuration;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 10:50 2021/2/22
 */
@Configuration
public class WebConfig extends BaseWebMvcConfig {

}
