package com.zhaopin.test.sdk2.model.pojo;

import java.time.Instant;

public class LiveRoom {
    /**
     * 直播间ID
     */
    private Long roomId;

    /**
     * 状态：0无效，1有效
     */
    private Integer state;

    /**
     * 创建时间
     */
    private Instant createTime;

    /**
     * 修改时间
     */
    private Instant modifiedTime;

    /**
     * 数据产生时的数据库时间
     */
    private Instant databaseCreateTime;

    /**
     * 数据修改时的数据库时间
     */
    private Instant databaseModifiedTime;

    /**
     * 创建人ID
     */
    private Long creatorId;

    /**
     * 视频直播状态:1未开始，2进行中，3已结束
     */
    private Integer liveState;

    /**
     * 视频直播开始时间
     */
    private Instant startTime;

    /**
     * 视频直播结束时间
     */
    private Instant endTime;

    /**
     * 直播封面url
     */
    private String coverUrl;

    /**
     * 直播主题
     */
    private String topic;

    /**
     * 直播slogan
     */
    private String slogan;

    /**
     * 混流状态：1未开始，2混流中，3已结束
     */
    private Integer mixState;

    /**
     * 回放视频状态：1未生成，2已生成
     */
    private Integer recordState;

    /**
     * 创建者类型：2 B端用户，3C端用户
     */
    private Integer creatorType;

    /**
     * 产生数据的业务类型
     */
    private Integer sideBusinessType;

    /**
     * 产生数据的业务子类型
     */
    private String sideBusinessSubtype;

    /**
     * 详细信息：业务场景数据
     */
    private String detail;

    /**
     * 直播可见性,主要针对C端推送：1公开，2业务线公开，3私密
     */
    private Integer visibility;

    /**
     * 公司id
     */
    private Long rootOrgId;

    /**
     * 公司名称
     */
    private String rootOrgName;

    /**
     * 直播观看人数
     */
    private Long viewCount;

    /**
     * 公司编号
     */
    private String orgNumber;

    /**
     * 直播模式：1直播，2面试
     */
    private Integer mode;

    /**
     * 视频直播实际开始时间
     */
    private Instant realStartTime;

    /**
     * 视频直播实际结束时间
     */
    private Instant realEndTime;

    /**
     * 获取直播间ID
     *
     * @return room_id - 直播间ID
     */
    public Long getRoomId() {
        return roomId;
    }

    /**
     * 设置直播间ID
     *
     * @param roomId 直播间ID
     */
    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    /**
     * 获取状态：0无效，1有效
     *
     * @return state - 状态：0无效，1有效
     */
    public Integer getState() {
        return state;
    }

    /**
     * 设置状态：0无效，1有效
     *
     * @param state 状态：0无效，1有效
     */
    public void setState(Integer state) {
        this.state = state;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Instant getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取修改时间
     *
     * @return modified_time - 修改时间
     */
    public Instant getModifiedTime() {
        return modifiedTime;
    }

    /**
     * 设置修改时间
     *
     * @param modifiedTime 修改时间
     */
    public void setModifiedTime(Instant modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    /**
     * 获取数据产生时的数据库时间
     *
     * @return database_create_time - 数据产生时的数据库时间
     */
    public Instant getDatabaseCreateTime() {
        return databaseCreateTime;
    }

    /**
     * 设置数据产生时的数据库时间
     *
     * @param databaseCreateTime 数据产生时的数据库时间
     */
    public void setDatabaseCreateTime(Instant databaseCreateTime) {
        this.databaseCreateTime = databaseCreateTime;
    }

    /**
     * 获取数据修改时的数据库时间
     *
     * @return database_modified_time - 数据修改时的数据库时间
     */
    public Instant getDatabaseModifiedTime() {
        return databaseModifiedTime;
    }

    /**
     * 设置数据修改时的数据库时间
     *
     * @param databaseModifiedTime 数据修改时的数据库时间
     */
    public void setDatabaseModifiedTime(Instant databaseModifiedTime) {
        this.databaseModifiedTime = databaseModifiedTime;
    }

    /**
     * 获取创建人ID
     *
     * @return creator_id - 创建人ID
     */
    public Long getCreatorId() {
        return creatorId;
    }

    /**
     * 设置创建人ID
     *
     * @param creatorId 创建人ID
     */
    public void setCreatorId(Long creatorId) {
        this.creatorId = creatorId;
    }

    /**
     * 获取视频直播状态:1未开始，2进行中，3已结束
     *
     * @return live_state - 视频直播状态:1未开始，2进行中，3已结束
     */
    public Integer getLiveState() {
        return liveState;
    }

    /**
     * 设置视频直播状态:1未开始，2进行中，3已结束
     *
     * @param liveState 视频直播状态:1未开始，2进行中，3已结束
     */
    public void setLiveState(Integer liveState) {
        this.liveState = liveState;
    }

    /**
     * 获取视频直播开始时间
     *
     * @return start_time - 视频直播开始时间
     */
    public Instant getStartTime() {
        return startTime;
    }

    /**
     * 设置视频直播开始时间
     *
     * @param startTime 视频直播开始时间
     */
    public void setStartTime(Instant startTime) {
        this.startTime = startTime;
    }

    /**
     * 获取视频直播结束时间
     *
     * @return end_time - 视频直播结束时间
     */
    public Instant getEndTime() {
        return endTime;
    }

    /**
     * 设置视频直播结束时间
     *
     * @param endTime 视频直播结束时间
     */
    public void setEndTime(Instant endTime) {
        this.endTime = endTime;
    }

    /**
     * 获取直播封面url
     *
     * @return cover_url - 直播封面url
     */
    public String getCoverUrl() {
        return coverUrl;
    }

    /**
     * 设置直播封面url
     *
     * @param coverUrl 直播封面url
     */
    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    /**
     * 获取直播主题
     *
     * @return topic - 直播主题
     */
    public String getTopic() {
        return topic;
    }

    /**
     * 设置直播主题
     *
     * @param topic 直播主题
     */
    public void setTopic(String topic) {
        this.topic = topic;
    }

    /**
     * 获取直播slogan
     *
     * @return slogan - 直播slogan
     */
    public String getSlogan() {
        return slogan;
    }

    /**
     * 设置直播slogan
     *
     * @param slogan 直播slogan
     */
    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    /**
     * 获取混流状态：1未开始，2混流中，3已结束
     *
     * @return mix_state - 混流状态：1未开始，2混流中，3已结束
     */
    public Integer getMixState() {
        return mixState;
    }

    /**
     * 设置混流状态：1未开始，2混流中，3已结束
     *
     * @param mixState 混流状态：1未开始，2混流中，3已结束
     */
    public void setMixState(Integer mixState) {
        this.mixState = mixState;
    }

    /**
     * 获取回放视频状态：1未生成，2已生成
     *
     * @return record_state - 回放视频状态：1未生成，2已生成
     */
    public Integer getRecordState() {
        return recordState;
    }

    /**
     * 设置回放视频状态：1未生成，2已生成
     *
     * @param recordState 回放视频状态：1未生成，2已生成
     */
    public void setRecordState(Integer recordState) {
        this.recordState = recordState;
    }

    /**
     * 获取创建者类型：2 B端用户，3C端用户
     *
     * @return creator_type - 创建者类型：2 B端用户，3C端用户
     */
    public Integer getCreatorType() {
        return creatorType;
    }

    /**
     * 设置创建者类型：2 B端用户，3C端用户
     *
     * @param creatorType 创建者类型：2 B端用户，3C端用户
     */
    public void setCreatorType(Integer creatorType) {
        this.creatorType = creatorType;
    }

    /**
     * 获取产生数据的业务类型
     *
     * @return side_business_type - 产生数据的业务类型
     */
    public Integer getSideBusinessType() {
        return sideBusinessType;
    }

    /**
     * 设置产生数据的业务类型
     *
     * @param sideBusinessType 产生数据的业务类型
     */
    public void setSideBusinessType(Integer sideBusinessType) {
        this.sideBusinessType = sideBusinessType;
    }

    /**
     * 获取产生数据的业务子类型
     *
     * @return side_business_subtype - 产生数据的业务子类型
     */
    public String getSideBusinessSubtype() {
        return sideBusinessSubtype;
    }

    /**
     * 设置产生数据的业务子类型
     *
     * @param sideBusinessSubtype 产生数据的业务子类型
     */
    public void setSideBusinessSubtype(String sideBusinessSubtype) {
        this.sideBusinessSubtype = sideBusinessSubtype;
    }

    /**
     * 获取详细信息：业务场景数据
     *
     * @return detail - 详细信息：业务场景数据
     */
    public String getDetail() {
        return detail;
    }

    /**
     * 设置详细信息：业务场景数据
     *
     * @param detail 详细信息：业务场景数据
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }

    /**
     * 获取直播可见性,主要针对C端推送：1公开，2业务线公开，3私密
     *
     * @return visibility - 直播可见性,主要针对C端推送：1公开，2业务线公开，3私密
     */
    public Integer getVisibility() {
        return visibility;
    }

    /**
     * 设置直播可见性,主要针对C端推送：1公开，2业务线公开，3私密
     *
     * @param visibility 直播可见性,主要针对C端推送：1公开，2业务线公开，3私密
     */
    public void setVisibility(Integer visibility) {
        this.visibility = visibility;
    }

    /**
     * 获取公司id
     *
     * @return root_org_id - 公司id
     */
    public Long getRootOrgId() {
        return rootOrgId;
    }

    /**
     * 设置公司id
     *
     * @param rootOrgId 公司id
     */
    public void setRootOrgId(Long rootOrgId) {
        this.rootOrgId = rootOrgId;
    }

    /**
     * 获取公司名称
     *
     * @return root_org_name - 公司名称
     */
    public String getRootOrgName() {
        return rootOrgName;
    }

    /**
     * 设置公司名称
     *
     * @param rootOrgName 公司名称
     */
    public void setRootOrgName(String rootOrgName) {
        this.rootOrgName = rootOrgName;
    }

    /**
     * 获取直播观看人数
     *
     * @return view_count - 直播观看人数
     */
    public Long getViewCount() {
        return viewCount;
    }

    /**
     * 设置直播观看人数
     *
     * @param viewCount 直播观看人数
     */
    public void setViewCount(Long viewCount) {
        this.viewCount = viewCount;
    }

    /**
     * 获取公司编号
     *
     * @return org_number - 公司编号
     */
    public String getOrgNumber() {
        return orgNumber;
    }

    /**
     * 设置公司编号
     *
     * @param orgNumber 公司编号
     */
    public void setOrgNumber(String orgNumber) {
        this.orgNumber = orgNumber;
    }

    /**
     * 获取直播模式：1直播，2面试
     *
     * @return mode - 直播模式：1直播，2面试
     */
    public Integer getMode() {
        return mode;
    }

    /**
     * 设置直播模式：1直播，2面试
     *
     * @param mode 直播模式：1直播，2面试
     */
    public void setMode(Integer mode) {
        this.mode = mode;
    }

    /**
     * 获取视频直播实际开始时间
     *
     * @return real_start_time - 视频直播实际开始时间
     */
    public Instant getRealStartTime() {
        return realStartTime;
    }

    /**
     * 设置视频直播实际开始时间
     *
     * @param realStartTime 视频直播实际开始时间
     */
    public void setRealStartTime(Instant realStartTime) {
        this.realStartTime = realStartTime;
    }

    /**
     * 获取视频直播实际结束时间
     *
     * @return real_end_time - 视频直播实际结束时间
     */
    public Instant getRealEndTime() {
        return realEndTime;
    }

    /**
     * 设置视频直播实际结束时间
     *
     * @param realEndTime 视频直播实际结束时间
     */
    public void setRealEndTime(Instant realEndTime) {
        this.realEndTime = realEndTime;
    }
}