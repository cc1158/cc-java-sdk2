package com.zhaopin.test.sdk2.mq.processor;

import com.cc.sdk2.rabbitmq.MessageProcessor;
import com.cc.sdk2.rabbitmq.spring.ConsumerId;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 13:45 2021/2/23
 */
@ConsumerId(id = "msgCenterConsumer")
@Component
public class MsgCenterProcessor implements MessageProcessor {

    @Override
    public void process(String s, long l, Map<String, Object> map, byte[] bytes) {
        String msg = new String(bytes, StandardCharsets.UTF_8);
        System.out.println("routingkey=" + s +  "\t msg = " + msg);
    }
}
