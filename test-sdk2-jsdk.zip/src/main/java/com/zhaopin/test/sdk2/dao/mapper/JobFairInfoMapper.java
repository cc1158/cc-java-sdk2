package com.zhaopin.test.sdk2.dao.mapper;

import com.cc.sdk2.jsdk.commons.mybatis.BaseMapper;
import com.zhaopin.test.sdk2.model.pojo.JobFairInfo;
import org.apache.ibatis.annotations.Param;

public interface JobFairInfoMapper extends BaseMapper<JobFairInfo, Integer> {

}