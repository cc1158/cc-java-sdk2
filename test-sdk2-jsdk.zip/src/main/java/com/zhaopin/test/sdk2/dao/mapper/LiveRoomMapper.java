package com.zhaopin.test.sdk2.dao.mapper;

import com.cc.sdk2.jsdk.commons.mybatis.BaseMapper;
import com.zhaopin.test.sdk2.model.pojo.LiveRoom;

public interface LiveRoomMapper extends BaseMapper<LiveRoom, Long> {

}