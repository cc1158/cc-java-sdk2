package com.zhaopin.test.sdk2.dao;

import com.cc.sdk2.jsdk.commons.mybatis.BaseDao;
import com.cc.sdk2.jsdk.datasource.annotation.Router;
import com.zhaopin.test.sdk2.dao.mapper.LiveRoomMapper;
import com.zhaopin.test.sdk2.model.pojo.LiveRoom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 15:10 2021/2/22
 */
@Router
@Repository
public class LiveRoomDao extends BaseDao<LiveRoom, Long> {

    @Autowired
    private LiveRoomMapper liveRoomMapper;

    @PostConstruct
    @Override
    protected void setBaseMapper() {
        super.baseMapper = liveRoomMapper;
    }

    public LiveRoom getByLiveRoomId(Long liveRoomId) {
        return liveRoomMapper.selectByPrimaryKey(liveRoomId);
    }

}
