package com.zhaopin.test.sdk2.dao;

import com.cc.sdk2.jsdk.commons.mybatis.BaseDao;
import com.cc.sdk2.jsdk.datasource.annotation.Router;
import com.zhaopin.test.sdk2.dao.mapper.JobFairInfoMapper;
import com.zhaopin.test.sdk2.dao.router.KsDataSourceRouter;
import com.zhaopin.test.sdk2.model.pojo.JobFairInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 15:24 2021/2/22
 */
@Repository
@Router(value = KsDataSourceRouter.class)
public class JobFairInfoDao extends BaseDao<JobFairInfo, Integer> {

    @Autowired
    private JobFairInfoMapper jobFairInfoMapper;

    @PostConstruct
    @Override
    protected void setBaseMapper() {
        super.baseMapper = jobFairInfoMapper;
    }

    public JobFairInfo getById(Integer jobFairId) {
        return jobFairInfoMapper.selectByPrimaryKey(jobFairId);
    }
}
