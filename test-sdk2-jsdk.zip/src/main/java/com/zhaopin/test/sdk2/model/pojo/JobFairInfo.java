package com.zhaopin.test.sdk2.model.pojo;


public class JobFairInfo {
    private Long id;
    private String jobFairName;
    private Integer jobFairWay;
    private String imageUrl;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobFairName() {
        return jobFairName;
    }

    public void setJobFairName(String jobFairName) {
        this.jobFairName = jobFairName;
    }

    public Integer getJobFairWay() {
        return jobFairWay;
    }

    public void setJobFairWay(Integer jobFairWay) {
        this.jobFairWay = jobFairWay;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
