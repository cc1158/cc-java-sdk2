package com.zhaopin.test.sdk2.mq;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 13:44 2021/2/23
 */
public class Test {
}
