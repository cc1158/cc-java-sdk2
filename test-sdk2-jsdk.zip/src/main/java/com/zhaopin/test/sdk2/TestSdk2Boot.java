package com.zhaopin.test.sdk2;

import com.cc.sdk2.springboot.web.EnableSdkSpringbootWeb;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 10:46 2021/2/22
 */
@SpringBootApplication
@EnableSdkSpringbootWeb
@MapperScan(basePackages = {"com.zhaopin.test.sdk2.dao.mapper"})
public class TestSdk2Boot {
    public static void main(String[] args) {
        SpringApplication.run(TestSdk2Boot.class, args);

    }
}
