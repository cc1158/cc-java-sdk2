package com.zhaopin.test.sdk2.dao.router;

import com.cc.sdk2.jsdk.datasource.router.DataSourceRouter;

import javax.sql.DataSource;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * Description
 *
 * @author sen.hu@zhaopin.com
 * @date 15:43 2021/2/22
 */
public class KsDataSourceRouter implements DataSourceRouter {
    @Override
    public String calculateDataSourceKey(Method method, Object[] objects, Class<?> aClass, Map<String, DataSource> map) {
        return "kongshuang";
    }
}
